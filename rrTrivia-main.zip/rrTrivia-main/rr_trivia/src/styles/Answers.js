import styled from 'styled-components';

const Answers = styled.div`
    display: grid;
    gap: 15px;
    grid-template-columns: 1fr ;
    margin: auto;


    
`

export default Answers;