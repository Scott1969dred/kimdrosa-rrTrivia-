import styled from 'styled-components';

const Button2 = styled.button`
    background-color: black ;
    border: solid;
    font-size: 25px;
    padding:20px;
    /* width: 100px; */
    color: white;
    border-radius: 5px;
`
 
export default Button2;