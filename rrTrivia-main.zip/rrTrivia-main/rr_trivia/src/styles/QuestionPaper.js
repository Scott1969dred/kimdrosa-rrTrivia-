import styled from 'styled-components';

const QuestionPaper = styled.div`
    display: block;
    background-color: white;
    width: 70%;

    margin: auto;
  
    margin-top:30px;
`

export default QuestionPaper;