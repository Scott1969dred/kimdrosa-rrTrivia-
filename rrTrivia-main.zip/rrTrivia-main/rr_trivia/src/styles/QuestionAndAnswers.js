import styled from 'styled-components';

const QuestionAndAnswers = styled.div`
    display: grid;
    grid-gap: 30px;

    margin: auto;

    
`

export default QuestionAndAnswers;