import styled from 'styled-components';

const H1 = styled.h1`

font-family: 'Ariel', sans-serif;
font-weight: 9000;
font-size: 50px;
color: white;
text-align: center;

`

export default H1;